"""GPL-3.0 adaptation of macroxue moving-hand evaluator, independent Python port.
Native30 arithmetic and initial previous-column=0 preserved. Extension MX34
adds only []\\' at their declared physical coordinates, all right pinky.
The cost unit is relative and is NOT milliseconds or measured fatigue.
"""
import math, string
ROWS=['qwertyuiop','asdfghjkl;','zxcvbnm,./']
COL=[0,1,2,3,3,6,6,7,8,9]
SPEED=[.6,.9,.9,1,1,1,1,.9,.9,.6]
LAYOUT={k:(x,y,COL[x]) for y,row in enumerate(ROWS) for x,k in enumerate(row)}
LAYOUT.update({'[':(10,0,9),']':(11,0,9),'\\':(12.25,0,9),"'":(10,1,9)})
KEYS=''.join(ROWS)+"[]\\'"
ALIASES={'FH':';','DH':',','JH':'.','CH':'/','YH':"'"}
def distance(x0,y0,x1,y1,staggered=True):
 if staggered:
  if y0>0:x0+=.25+(y0-1)*.5
  if y1>0:x1+=.25+(y1-1)*.5
 return math.sqrt((x0-x1)**2+(y0-y1)**2)
def pair(a,b,staggered=True):
 x0,y0,f0=LAYOUT[a];x1,y1,f1=LAYOUT[b];d=.2
 if f0==f1:d+=distance(x0,y0,x1,y1,staggered)
 elif (x0<5)==(x1<5):d+=distance(x0+f1-f0,y0,x1,y1,staggered)
 return d/SPEED[f1]
def parse(scheme):
 out={}
 for assignment in scheme.split(','):
  k,v=assignment.split('=',1);k=ALIASES.get(k,k.lower())
  for py in v.split():out[py]=out.get(py,'')+k
 for c in string.ascii_lowercase:out.setdefault(c,c)
 return out
def split(py):
 if py=='ng':py='eng'
 if py[0] in 'aeo':return '',py
 if len(py)>1 and py[0] in 'zcs' and py[1]=='h':return py[:2],py[2:]
 return py[:1],py[1:]
def encode(py,pm,staggered=True):
 head,final=split(py)
 if not head:head='0' if '0' in pm else final[0]
 if not final:return pm.get(head,'')
 if head not in pm or final not in pm:return ''
 combos=dict.fromkeys(a+b for a in pm[head] for b in pm[final])
 return min(combos,key=lambda c:pair(c[0],c[1],staggered))
def evaluate(strokes,chars=None,staggered=True):
 strokes=strokes.lower();n=len(strokes)
 bad=sorted(set(strokes)-set(LAYOUT))
 if bad:raise ValueError('Unsupported keystrokes: '+repr(bad))
 if n==0:raise ValueError('Empty corpus is not a benchmark')
 if chars is None:chars=n/2
 pos=[[0.,0.],[0.,0.]];last=0;lastfinger=0
 r=dict(hits=n,chars=chars,time=0.,effective_distance=0.,overlap_distance=0.,same_hand_hits=0,same_finger_hits=[0]*16,diff_finger_hits=[0]*16,heat_map={k:0 for k in KEYS})
 for k in strokes:
  x,y,f=LAYOUT[k];hand=int(x>=5);same=(hand==int(last>=5));x0=f+pos[hand][0];y0=1+pos[hand][1];pos[hand]=[x-f,y-1]
  d=.2+(distance(x0,y0,x,y,staggered) if same else 0.)
  r['time']+=d/SPEED[f];r['effective_distance']+=d;r['heat_map'][k]+=1
  if same:r['same_hand_hits']+=1
  else:r['overlap_distance']+=distance(x0,y0,x,y,staggered)
  if f==lastfinger:r['same_finger_hits'][math.floor(d)]+=1
  elif same:r['diff_finger_hits'][math.floor(d)]+=1
  last=x;lastfinger=f
 row=[0]*3;finger=[0]*10;left=0
 for k,v in r['heat_map'].items():
  x,y,f=LAYOUT[k];row[y]+=v;finger[f]+=v;left+=v if x<5 else 0
 r.update(score=chars/r['time']*200,speed=n/r['time']*100,total_distance=r['effective_distance']+r['overlap_distance'],row_load=row,finger_load=finger,left_load=left,right_load=n-left,avg_time=r['time']/n,avg_distance=(r['effective_distance']+r['overlap_distance'])/n,avg_effective_distance=r['effective_distance']/n,avg_overlap_distance=r['overlap_distance']/n,same_hand_rate=r['same_hand_hits']/n,shapeIncluded=False,spaceIncluded=False,unit='relative hand-model cost; not ms')
 return r
