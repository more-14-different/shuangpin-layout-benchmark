#!/usr/bin/env python3
"""Integrate the six reviewed M42/D2 QZ+ZQ-empty 21x21 schemes into R11."""

from __future__ import annotations

import copy
import collections
import argparse
import hashlib
import importlib
import json
import math
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SNOW = Path(r"D:\C2D\Documents\rime-snow-pinyin")
RESEARCH = SNOW / "scripts" / "research"
HTML = ROOT / "a7_CKT_R11.html"
REPLAY = ROOT / "research" / ".cache" / "R11_integrated_replay"
V5_CACHE = REPLAY / "exact-v5-v51-21x21"
AUDIT = (
    ROOT / "a7_CKT_R11_integrated_materials"
    / "a7_qz_zq_empty_m42d2_six_benchmark.json"
)
SOURCE_BRANCH = "production/ckt-v4-2121-strict-avuio-20261024"
SOURCE_COMMIT = "f247355"
TONE_KEYS_BY_TONE = "IVUAO"
SHAPE_KEYS_BY_MEANING = "AVUIO"
TONE_DIGITS_BY_SHAPE_MEANING = "42310"
E8F37A_ID = "QZ-e8f37a0998f9"
E8F37A_ROBUSTNESS = {
    "version": "e8f37a-ckt51-aux-order-robustness-1",
    "report": "research/notes/2026-11-09-e8f37a-ckt-v51-aux-order-robustness.md",
    "selectedPolicies": {
        "keytao": {"word2": "12", "word3": "213", "word4": "24"},
        "sanpin": {"word2": "12", "word3": "213", "word4": "23"},
    },
    "cases": {
        "keytao": {
            "main0To500Step50": {
                "winner": {"policy": "12/213/24", "meanRank": 1.1810668670172801},
                "runnerUp": {"policy": "12/231/24", "meanRank": 1.9415634008651128},
                "meanRankDistance": 0.7604965338478327,
            },
            "mainPositive50To500Step50": {
                "winner": {"policy": "12/213/24", "meanRank": 1.109},
                "runnerUp": {"policy": "12/231/24", "meanRank": 1.952278},
                "meanRankDistance": 0.843278,
            },
            "extreme0To1000Step100": {
                "winner": {"policy": "12/213/24", "meanRank": 1.1502629601803156},
                "runnerUp": {"policy": "12/231/24", "meanRank": 2.0330911552015425},
                "meanRankDistance": 0.8828281950212269,
            },
            "extremePositive100To1000Step100": {
                "winner": {"policy": "12/213/24", "meanRank": 1.079},
                "runnerUp": {"policy": "12/231/24", "meanRank": 2.014432},
                "meanRankDistance": 0.9354319999999998,
            },
        },
        "sanpin": {
            "main0To500Step50": {
                "winner": {"policy": "12/213/23", "meanRank": 2.2261192247966624},
                "runnerUp": {"policy": "12/213/21", "meanRank": 3.7478624783453687},
                "meanRankDistance": 1.5217432535487063,
            },
            "mainPositive50To500Step50": {
                "winner": {"policy": "12/213/23", "meanRank": 1.43565},
                "runnerUp": {"policy": "12/213/21", "meanRank": 2.723167},
                "meanRankDistance": 1.287517,
            },
            "extreme0To1000Step100": {
                "winner": {"policy": "12/213/23", "meanRank": 1.6540632809144027},
                "runnerUp": {"policy": "12/213/21", "meanRank": 2.748019966571854},
                "meanRankDistance": 1.0939566856574512,
            },
            "extremePositive100To1000Step100": {
                "winner": {"policy": "12/213/23", "meanRank": 1.212486},
                "runnerUp": {"policy": "12/213/21", "meanRank": 2.121716},
                "meanRankDistance": 0.9092300000000002,
            },
        },
    },
}
ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ[]\\;',./"
HEADS = [
    "b", "p", "m", "f", "d", "t", "n", "l", "g", "k", "h", "j",
    "q", "x", "zh", "ch", "sh", "r", "z", "c", "s", "A", "E", "O",
    "W", "Y", "YU",
]
FINALS = [
    "a", "ai", "an", "ang", "ao", "e", "ei", "en", "eng", "er", "i",
    "ia", "ian", "iang", "iao", "ie", "in", "ing", "iong", "iu", "o",
    "ong", "ou", "u", "ua", "uai", "uan", "uang", "ui", "un", "uo",
    "v", "van", "ve", "vn",
]
TRACK_WEIGHTS = {"character": 1, "word2": 3, "word3": 1, "word4": 1}
NATIVE_B_PATHS = (
    ("j1", "keytao", "character", "p1"),
    ("j2", "keytao", "character", "p2"),
    ("s1", "sanpin", "character", "p1"),
    ("s2", "sanpin", "character", "p2"),
    ("wj1", "keytao", "word", "p1"),
    ("wj2", "keytao", "word", "p2"),
    ("ws1", "sanpin", "word", "p1"),
    ("ws2", "sanpin", "word", "p2"),
)

CANDIDATES = [
    {
        "id": "QZ-1a16aa4efe93",
        "label": "综合中心",
        "archivedCktV4": 9.576377236511233,
        "stateKey": "1515010f0c0503130d04060f070910170a120b1119021211021116181809070c1819120b031309050b0f091002110a0d01060b160d1017040211060a03130406081514000e",
    },
    {
        "id": "QZ-e8f37a0998f9",
        "label": "近邻速度型",
        "archivedCktV4": 9.56073454942596,
        "stateKey": "1515010f0c0503130d04060f070910170a120b111902121102111618180f0d0c1819120b031309050b090f1002110a0701060b16071017040211060a03130406081514000e",
    },
    {
        "id": "QZ-c6f1cd673f93",
        "label": "速度端点",
        "archivedCktV4": 9.55283864991326,
        "stateKey": "1515010f0c0503130d04060f070910170a120b111902121102111618180b0c031819120f04130d050f0d0b1002110a1806010f16070217091011010a04130701081514000e",
    },
    {
        "id": "QZ-ffc213d4eda1",
        "label": "低 TYB／低异键同指端点",
        "archivedCktV4": 9.591254911945663,
        "stateKey": "1515010f0c0503130d04060f070910170b120a111902121102111618180b070d1816120f041109050f090b1002040a1806060f030c1017190213060a13110701081514000e",
    },
    {
        "id": "QZ-69bef3e03438",
        "label": "低单指／低异键同指端点",
        "archivedCktV4": 9.630363234043132,
        "stateKey": "1515010f0c0503130d04060f070910170a120b111902121102111618180b170d1819120f041109050f090b0702130a1801030f160c0710060203130a04111703081514000e",
    },
    {
        "id": "QZ-39397c912347",
        "label": "低 TYB 极端端点",
        "archivedCktV4": 9.62504838122717,
        "stateKey": "1515010f0c0503130d04060f070910170a120b111902121105111618180b07020c03120f04110a050f090b1002130a0c01060f160d1017190613060a04110718081514000e",
    },
]


def run(*args: str, cwd: Path | None = None) -> None:
    subprocess.run(list(args), cwd=cwd, check=True)


def decode_state(candidate: dict) -> dict:
    raw = bytes.fromhex(candidate["stateKey"])
    if len(raw) != 69 or list(raw[:2]) != [21, 21]:
        raise ValueError(f"invalid 21x21 state for {candidate['id']}: {len(raw)} bytes")
    if any(index >= len(ALPHABET) for index in raw[2:]):
        raise ValueError(f"key index outside alphabet for {candidate['id']}")
    initial_map = dict(zip(HEADS, (ALPHABET[index] for index in raw[2:29])))
    final_map = dict(zip(FINALS, (ALPHABET[index] for index in raw[29:64])))
    tone = "".join(ALPHABET[index] for index in raw[64:69])
    if tone != TONE_KEYS_BY_TONE:
        raise ValueError(f"unexpected toneKeysByTone for {candidate['id']}: {tone}")
    return {
        "id": candidate["id"],
        "initialMap": initial_map,
        "finalMap": final_map,
        "toneKeys": tone,
        "capacity": [21, 21],
        "actual": [21, 21],
        "M": 42,
        "D": 2,
        "V": 5,
        "label": candidate["label"],
        "atlasSubfamily": "21x21 M42 D2 QZ/ZQ empty reviewed basin",
        "atlasSource": f"{SOURCE_BRANCH}@{SOURCE_COMMIT}",
    }


def make_entry(helper, source: dict, split, candidate: dict) -> dict:
    scheme = decode_state(candidate)
    initial_map = scheme["initialMap"]
    final_map = scheme["finalMap"]
    split_y_yu = initial_map["Y"] != initial_map["YU"]
    code_list = []
    for spelling in source["pinyin"]:
        if spelling in helper.NOT_COMMON399:
            code_list.append(None)
            continue
        head, final = split(spelling, split_y_yu)
        code_list.append(initial_map[head] + final_map[final])
    common_codes = [code_list[index] for index, _ in source["base"]]
    digest = hashlib.sha256(
        json.dumps(code_list, ensure_ascii=False, separators=(",", ":")).encode()
    ).hexdigest()
    actual = [
        len({code[0] for code in common_codes}),
        len({code[1] for code in common_codes}),
    ]
    return {
        "id": candidate["id"],
        "name": f"冰雪神韵·QZ/ZQ 空桶·{candidate['label']}",
        "family": "Snow Shenyun 21x21",
        "subfamily": "AVUIO 锁定·M42/D2·QZ/ZQ 空桶",
        "source": f"{SOURCE_BRANCH}@{SOURCE_COMMIT}",
        "new": True,
        "codeList": code_list,
        "tone": TONE_KEYS_BY_TONE,
        "capacity": [21, 21],
        "actual": actual,
        "initialMap": initial_map,
        "finalMap": final_map,
        "roles": helper.onset_roles(initial_map),
        "zeroOnsetScope": helper.zero_onset_scope({"initialMap": initial_map}),
        "rhymes": helper.inverse(final_map),
        "reservedKeys": SHAPE_KEYS_BY_MEANING,
        "auxiliaryClass": "AVUIO",
        "defaultAuxOrder": False,
        "auxiliaryMappingMatchesReservation": True,
        "topgongReserve": SHAPE_KEYS_BY_MEANING,
        "topgongValid": True,
        "strictTopgong": True,
        "exceptionCount": 0,
        "searchMemoryNoTone": 42,
        "searchMetrics": {"M": 42, "D": 2},
        "mappingAudit": {
            "scope": "Common399; 21x21; fixed AVUIO auxiliary key set; QZ/ZQ empty",
            "codeListSha256": digest,
            "ordinaryInitialDisplacements": 2,
            "baseFinalDisplacements": 5,
            "aaVacancies": None,
            "qzEmpty": "QZ" not in common_codes,
            "zqEmpty": "ZQ" not in common_codes,
        },
        "r11Provenance": {
            "parent": None,
            "kind": "post-R11 21x21 M42/D2 QZ+ZQ empty reviewed basin candidate",
            "soundLayout": candidate["id"],
            "branch": SOURCE_BRANCH,
            "commit": SOURCE_COMMIT,
            "stateKey": candidate["stateKey"],
        },
        "productionCandidateMetrics": {
            "archivedCktV4": candidate.get("archivedCktV4"),
            "memory": 42,
            "displacedInitials": 2,
            "displacedVowels": 5,
            "qzEmpty": True,
            "zqEmpty": True,
        },
        "notes": [
            "21x21；M42、D2、V5；QZ 与 ZQ 均为空桶；Common399 重码按实际桶补全计费。",
            "toneKeysByTone=IVUAO；shapeKeysByMeaning=AVUIO；toneDigitsByShapeMeaning=42310。",
            "普通声母位移为 l->E、k->P；其余差异属于复声母／零声母路由。",
        ],
    }


def aggregate_completion(scheme: dict) -> dict[str, float]:
    fields = (
        "motorUpperMs", "cognitiveMs", "effectiveMs", "firstAuxRate",
        "secondAuxRate", "thirdAuxRate", "selectionRate",
        "meanRejectedCandidates", "meanPageActions", "meanKeys",
    )
    result = {field: 0.0 for field in fields}
    denominator = 0
    for mode in ("keytao", "sanpin"):
        for kind, weight in TRACK_WEIGHTS.items():
            track = scheme["modes"][mode][kind]
            for field in fields:
                value = track.get(field, 0) or 0
                if field == "cognitiveMs" and not math.isfinite(value):
                    value = track["effectiveMs"] - track["motorUpperMs"]
                result[field] += weight * value
            denominator += weight
    return {field: value / denominator for field, value in result.items()}


def score_v5_v51_21x21(
    scorer_source: Path, staged: Path, output: Path, ident: str, temp: Path,
    *, keytao_word3: str | None = None, sanpin_word4: str = "23",
) -> dict:
    v51_keytao_word3 = keytao_word3 or ("213" if ident == E8F37A_ID else "231")
    if v51_keytao_word3 not in {"213", "231"}:
        raise ValueError("unsupported 21x21 v5.1 Keytao word3 policy")
    if sanpin_word4 not in {"12", "21", "23"}:
        raise ValueError("unsupported 21x21 v5.1 Sanpin word4 policy")
    source = scorer_source.read_text(encoding="utf-8")
    source = source.replace(
        'require("./auxiliary_semantics.js")',
        f"require({json.dumps(str(ROOT / 'tools' / 'auxiliary_semantics.js'))})",
        1,
    )
    source = source.replace(
        'keytao: { word2: "12", word3: "21", word4: "42" },\n'
        '    sanpin: { word2: "12", word3: "21", word4: "13" },',
        'keytao: { word2: "12", word3: "23", word4: "24" },\n'
        '    sanpin: { word2: "12", word3: "21", word4: "23" },',
        1,
    )
    source = source.replace(
        'keytao: { word2: "12", word3: "21", word4: "14" },\n'
        '    sanpin: { word2: "12", word3: "21", word4: "13" },',
        f'keytao: {{ word2: "12", word3: "{v51_keytao_word3}", word4: "24" }},\n'
        f'    sanpin: {{ word2: "12", word3: "213", word4: "{sanpin_word4}" }},',
        1,
    )
    v51_at = source.index("const V51_POLICIES")
    v51_source = source[v51_at:].replace(
        'keytao: { word2: "12", word3: "21", word4: "24" },\n'
        '    sanpin: { word2: "12", word3: "21", word4: "23" },',
        'keytao: { word2: "12", word3: "231", word4: "24" },\n'
        '    sanpin: { word2: "12", word3: "213", word4: "23" },',
        1,
    )
    source = source[:v51_at] + v51_source
    source = source.replace(
        'if (entry.capacity[0] !== 21 || entry.capacity[1] !== 26) {\n'
        '    throw new Error(`scheme is not 21x26: ${entry.capacity}`);\n  }',
        'if (entry.capacity[0] !== 21 || entry.capacity[1] !== 21) {\n'
        '    throw new Error(`scheme is not 21x21: ${entry.capacity}`);\n  }',
        1,
    )
    source = source.replace(
        'const benchmark = path.resolve(__dirname, "..");',
        f"const benchmark = {json.dumps(str(ROOT))};",
        1,
    )
    source = source.replace(
        '[mode, evaluateV51CandidateMode(entry, mode, V51_POLICIES.candidate[mode])]',
        '[mode, evaluateV51ReferenceMode(entry, mode, V51_POLICIES.candidate[mode])]',
        1,
    )
    source = source.replace(
        'ckt-v5-v5.1-fixed-21x26-production-policies-1',
        'ckt-v5-v5.1-fixed-21x21-production-policies-2',
        1,
    )
    generated = temp / f"score-{ident}.js"
    generated.write_text(source, encoding="utf-8")
    run(
        "node", str(generated), "--id", ident, "--html", str(staged),
        "--snow", str(SNOW), "--output", str(output), cwd=ROOT,
    )
    return json.loads(output.read_text(encoding="utf-8"))


def group_peak(data: dict, ident: str, group: str) -> dict:
    keys = data["ckt"]["keys"]
    rows = []
    for track, metric in data["ckt"]["tracks"][ident].items():
        value = sum(metric["load"][keys.index(key)] for key in group)
        rows.append((value, track))
    value, track = max(rows)
    return {"value": value, "track": track}


def readme_metrics(data: dict, entry: dict, v5_v51: dict, production) -> dict:
    ident = entry["id"]
    completion = data["completionBV4"]["schemes"][ident]
    aggregate = aggregate_completion(completion)
    fair = data["fairCKT"]["values"][ident]
    macro = data["macroxue"]["values"][ident]["daily|native-punctuation"]
    load = data["r11LoadSummaries"][ident]
    common_codes = [entry["codeList"][index] for index, _ in data["base"]]
    buckets = collections.Counter(common_codes)
    colliding = [size for size in buckets.values() if size > 1]
    unique = fair["unique399"]
    return {
        "M-R2": entry["memoryAuditR2"]["M"],
        "flyingKeyComponents": {"initials": 0, "zeroInitialGroups": 0, "finals": 0},
        "logicAuditFA1": entry["logicAudit"]["score"],
        "logicUniformityLUv1r": entry["logicUniformity"]["score"],
        "common399UniqueCodes": unique,
        "common399UniqueRate": unique / 399,
        "common399CollisionExcess": 399 - unique,
        "common399CollisionBuckets": len(colliding),
        "common399AffectedSyllables": sum(colliding),
        "common399AffectedRate": sum(colliding) / 399,
        "s2FrequencyWeightedMiss": fair["S2miss"],
        "s2CompletionMeanKeys": fair["S2Completion"]["meanKeys"],
        "s2CompletionCenterMs": fair["S2Completion"]["centerMs"],
        "s2DifferentKeySameFingerRate": data["ckt"]["tracks"][ident]["S2"]["sfb"],
        "cktV3": production.score_v3(
            data["completionBV3"]["schemes"][ident]["modes"],
            data["completionBV3"]["schemes"]["S005"]["modes"],
        ),
        "cktV4": production.score_v4(
            completion["modes"],
            data["completionBV4"]["schemes"]["S005"]["modes"],
            data["completionBV4"]["cognitiveDefaults"],
        ),
        "cktV5": v5_v51["cktV5"]["score"],
        "cktV51": v5_v51["cktV51"]["score"],
        "ensembleV3": data["ensembleV3"]["values"][ident]["score"],
        "ensembleV4": data["ensembleV4"]["values"][ident]["score"],
        "ensembleV5": data["ensembleV5"]["values"][ident]["score"],
        "ensembleV6CW150": data["ensembleV6"]["values"][ident]["score"],
        "aggregateSelectionRate": aggregate["selectionRate"],
        "aggregateFirstAuxRate": aggregate["firstAuxRate"],
        "aggregateSecondAuxRate": aggregate["secondAuxRate"],
        "dailyLeftRightLoad": {
            "left": macro["left_load"], "right": macro["right_load"],
            "leftShare": macro["left_load"] / macro["hits"],
        },
        "dailySameHandRate": macro["same_hand_rate"],
        "dailyMeanEffectiveDistance": macro["avg_effective_distance"],
        "leftPinkyQAZPeak20Contracts": group_peak(data, ident, "QAZ"),
        "rightPinkyPeak20Contracts": {
            "value": load["rightPinkyMax20"], "track": load["rightPinkyTrack"]
        },
        "maxFingerPeak20Contracts": load["maxFinger20"],
        "homeShareS2": load["homeS2"],
        "homeFloor20Contracts": min(
            track["home"] for track in data["ckt"]["tracks"][ident].values()
        ),
        "indexFingerTYBPeak20Contracts": group_peak(data, ident, "TYB"),
        "dailyEightScenarioMovingHand": macro["score"],
        "dailyAverageOverlapDistance": macro["avg_overlap_distance"],
        "dailyAverageTotalDistance": macro["avg_distance"],
        "dailyAverageTime": macro["avg_time"],
    }


def validate_expected(metrics: dict, expected: dict) -> None:
    for field, value in expected.items():
        if not math.isclose(metrics[field], value, rel_tol=0, abs_tol=1e-9):
            raise ValueError(f"benchmark anchor mismatch: {field}: {metrics[field]} != {value}")


def apply_robust_production_display(entry: dict, selection: dict) -> None:
    metrics = entry['productionCandidateMetrics']
    expected = {'keytao': {'word2': '12', 'word3': '213', 'word4': '24'},
                'sanpin': {'word2': '12', 'word3': '213', 'word4': '21'}}
    if metrics['cktV51Policies']['candidate'] != expected:
        raise ValueError('production display requires the audited robust policies')
    aggregate = metrics['cktV51Aggregate']
    if abs(aggregate['motorUpperMs'] + aggregate['cognitiveMs'] - aggregate['effectiveMs']) > 1e-9:
        raise ValueError('inconsistent production aggregate')
    # Every unversioned production attribute comes from the same v5.1 replay.
    for field in ('firstAuxRate', 'secondAuxRate', 'thirdAuxRate', 'selectionRate',
                  'motorUpperMs', 'cognitiveMs', 'effectiveMs', 'meanKeys',
                  'meanRejectedCandidates', 'meanPageActions'):
        entry['readmeBenchmarkMetrics']['aggregate' + field[0].upper() + field[1:]] = aggregate[field]
    entry['readmeBenchmarkMetrics'].pop('cktV51DefaultPointOptimal', None)
    for field in ('cktV51DefaultPointOptimal', 'cktV51DefaultPointPolicies', 'cktV51DefaultPointAggregate'):
        metrics.pop(field, None)
    metrics['cktV51AuxOrderSelection'] = selection
    metrics['productionMetricContract'] = 'CKT v5.1; robust auxiliary policies; character/word2/word3/word4=1:3:1:1; two members equally weighted'


def patch_production_ui(html: str) -> str:
    # Keep the visible policy labels out of numeric CSV score cells.
    html = html.replace("c.querySelectorAll('.dv-chip-line,.dv-cell-flag,.dv-row-label,.ux-sort')",
                        "c.querySelectorAll('.dv-chip-line,.dv-cell-flag,.dv-row-label,.ux-sort,.untoned-policy-label')", 1)
    hook = " /* UNTONED_PRODUCTION_COLUMNS_V1 */\n if(typeof untonedProductionTableColumns==='function')({headers,rows,ids,raws}=untonedProductionTableColumns(headers,rows,ids,key,raws));\n"
    if "/* UNTONED_PRODUCTION_COLUMNS_V1 */" not in html:
        anchor = "if(typeof snowJiandaoTableRows==='function')({headers,rows,ids,raws}=snowJiandaoTableRows(headers,rows,ids,key,raws));"
        if html.count(anchor) != 1:
            raise ValueError("expected exactly one final table-column adapter boundary")
        html = html.replace(anchor, anchor + "\n" + hook, 1)
    html = re.sub(r'\n?<script id="untoned-production-benchmark-ui">[\s\S]*?</script>\n?', '\n', html)
    source = (ROOT / "tools/untoned_production_benchmark_ui.js").read_text(encoding="utf-8")
    body_end = re.search(r'</body>\s*</html>\s*$', html)
    if body_end is None:
        raise ValueError("expected the document body end")
    return html[:body_end.start()].rstrip('\r\n') + '\n<script id="untoned-production-benchmark-ui">\n' + source + '\n</script>\n' + html[body_end.start():]


def fresh_exact_replay(entries: list[dict], replay: Path) -> dict:
    """Replay in private input/output files without touching shared cache jobs."""
    with tempfile.TemporaryDirectory(prefix="oc21-exact-") as location:
        temp = Path(location)
        inputs = temp / "entries.json"
        inputs.write_text(json.dumps(entries, ensure_ascii=False), encoding="utf-8")
        source = (replay / "eval_full.js").read_text(encoding="utf-8")
        substitutions = {
            "const R=__dirname;": f"const R={json.dumps(str(replay))};",
            "require('./script1.js')": f"require({json.dumps(str(replay / 'script1.js'))})",
            "require('./script2.js')": f"require({json.dumps(str(replay / 'script2.js'))})",
            "path.join(R,'entries_to_score.json')": json.dumps(str(inputs)),
            "path.join(R,'exact')": json.dumps(str(temp / "exact")),
        }
        for old, new in substitutions.items():
            if source.count(old) != 1:
                raise ValueError(f"frozen replay adapter boundary differs: {old}")
            source = source.replace(old, new, 1)
        runner = temp / "eval.js"
        runner.write_text(source, encoding="utf-8")
        run("node", "--max-old-space-size=1800", str(runner), "0", str(len(entries)), cwd=replay)
        return {e["id"]: json.loads((temp / "exact" / (e["id"] + ".json")).read_text(encoding="utf-8")) for e in entries}


def main() -> None:
    global HTML, REPLAY, V5_CACHE, AUDIT, CANDIDATES, SOURCE_BRANCH, SOURCE_COMMIT
    if not sys.flags.utf8_mode:
        environment = os.environ.copy()
        environment["PYTHONUTF8"] = "1"
        raise SystemExit(subprocess.call([sys.executable, *sys.argv], env=environment))

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html", type=Path, default=HTML)
    parser.add_argument("--replay", type=Path, default=REPLAY)
    parser.add_argument("--candidate-file", type=Path)
    parser.add_argument("--audit", type=Path, default=AUDIT)
    parser.add_argument("--replace-existing", action="store_true")
    parser.add_argument("--fresh", action="store_true", help="recompute native tracks and production CKT without score caches")
    args = parser.parse_args()
    HTML, REPLAY, AUDIT = args.html.resolve(), args.replay.resolve(), args.audit.resolve()
    candidate_source = None
    keytao_word3 = None
    sanpin_word4 = "23"
    if args.candidate_file:
        candidate_file = args.candidate_file.resolve()
        candidate_source = json.loads(candidate_file.read_text(encoding="utf-8"))
        CANDIDATES = candidate_source["candidates"]
        if not CANDIDATES or len({row["id"] for row in CANDIDATES}) != len(CANDIDATES):
            raise ValueError("candidate IDs must be nonempty and unique")
        SOURCE_BRANCH = candidate_source["source"]["branch"]
        SOURCE_COMMIT = candidate_source["source"]["commit"]
        keytao_word3 = candidate_source["v51KeytaoWord3"]
        sanpin_word4 = candidate_source.get("v51SanpinWord4", "23")
        for row in CANDIDATES:
            row.setdefault("archivedCktV4", None)
        # Separate these scores from the historical per-layout policy caches.
        V5_CACHE = REPLAY / "exact-v5-v51-21x21" / hashlib.sha256(candidate_file.read_bytes()).hexdigest()[:16]
    else:
        V5_CACHE = REPLAY / "exact-v5-v51-21x21"

    production = importlib.import_module("integrate_shenyun_21x26_production")
    sys.path.insert(0, str(RESEARCH))
    fixed = production.load_module(
        "fixed_frontier_qz_six",
        RESEARCH / "integrate_shenyun_21x21_completion_fixed_frontier.py",
    )
    old = production.load_module(
        "old_21x21_qz_six",
        RESEARCH / "integrate_shenyun_21x21_low_miss.py",
    )
    helper = old.load_helper(HTML)

    html = HTML.read_text(encoding="utf-8")
    data, body, end = helper.extract_payload(html)
    existing_ids = {entry["id"] for entry in data["entries"]}
    candidate_ids = {candidate["id"] for candidate in CANDIDATES}
    replaced_ids = []
    if args.replace_existing:
        if candidate_source is None:
            raise ValueError("replacement requires an explicit candidate file")
        # Replacement is limited to the listed layouts; reject mapping drift.
        for entry in data["entries"]:
            if entry["id"] in candidate_ids:
                expected = next(c for c in CANDIDATES if c["id"] == entry["id"])
                if entry.get("r11Provenance", {}).get("stateKey") != expected["stateKey"]:
                    raise ValueError("replacement mapping differs: " + entry["id"])
        replaced_ids = helper.prune_scheme_ids(data, candidate_ids)
        existing_ids -= set(replaced_ids)
    if candidate_ids <= existing_ids:
        update_payload = bool(candidate_source and candidate_source.get('productionDisplay') == 'robust-v51')
        for candidate in CANDIDATES:
            present = next(entry for entry in data["entries"] if entry["id"] == candidate["id"])
            if present.get("r11Provenance", {}).get("stateKey") != candidate["stateKey"]:
                raise ValueError(f"already-integrated mapping differs: {candidate['id']}")
            if any(candidate["id"] in missing for missing in production.missing_by_map(data, existing_ids).values()):
                raise ValueError(f"already-integrated benchmark incomplete: {candidate['id']}")
            if update_payload:
                apply_robust_production_display(present, candidate_source['auxOrderSelection'])
            validate_expected(present.get("readmeBenchmarkMetrics", {}), candidate.get("expected", {}))
        if candidate_source:
            patched = patch_production_ui(html)
            if update_payload or patched != html:
                if HTML.read_text(encoding="utf-8") != html:
                    raise ValueError("HTML changed while updating the table adapter")
                fixed.write_payload(HTML, patched, body, end, data)
        print(json.dumps({"alreadyIntegrated": sorted(candidate_ids), "catalogue": len(existing_ids)}))
        return
    if candidate_ids & existing_ids:
        raise ValueError("only part of the six-scheme cohort is already integrated")
    before_missing = production.missing_by_map(data, existing_ids)
    source = json.loads((REPLAY / "source.json").read_text(encoding="utf-8"))
    if source["pinyin"] != data["pinyin"]:
        raise ValueError("frozen replay and atlas pinyin indices differ")

    sys.path.insert(0, str(REPLAY))
    split = importlib.import_module("audit").split
    entries = []
    candidate_by_id = {candidate["id"]: candidate for candidate in CANDIDATES}
    for candidate in CANDIDATES:
        entry = make_entry(helper, source, split, candidate)
        common_codes = [entry["codeList"][index] for index, _ in source["base"]]
        if "QZ" in common_codes or "ZQ" in common_codes:
            raise ValueError(f"QZ/ZQ empty-bucket invariant failed: {entry['id']}")
        entry.update({
            "name": f"冰雪神韵·QZ/ZQ 空桶·{candidate['label']}",
            "family": "Snow Shenyun 21x21",
            "subfamily": "AVUIO 锁定·M42/D2·QZ/ZQ 空桶",
            "reservedKeys": SHAPE_KEYS_BY_MEANING,
            "auxiliaryClass": "AVUIO",
            "defaultAuxOrder": False,
            "topgongReserve": SHAPE_KEYS_BY_MEANING,
            "sourceSearchRound": "strict-avuio-stage-1-to-stage-2-reviewed-qz-basin",
            "r11Provenance": {
                "parent": None,
                "kind": "post-R11 21x21 M42/D2 QZ+ZQ empty reviewed basin candidate",
                "soundLayout": candidate["id"],
                "branch": SOURCE_BRANCH,
                "commit": SOURCE_COMMIT,
                "stateKey": candidate["stateKey"],
            },
            "productionCandidateMetrics": {
                "archivedCktV4": candidate.get("archivedCktV4"),
                "memory": 42,
                "displacedInitials": 2,
                "displacedVowels": 5,
                "qzEmpty": True,
                "zqEmpty": True,
            },
            "notes": [
                "21x21；Common399 399/399 唯一；M42、D2、V5；QZ 与 ZQ 均为空桶。",
                "toneKeysByTone=IVUAO；shapeKeysByMeaning=AVUIO；toneDigitsByShapeMeaning=42310。",
                "普通声母位移为 l->E、k->P；其余差异属于复声母／零声母路由。",
            ],
        })
        entry["mappingAudit"].update({
            "scope": "Common399; 21x21; fixed AVUIO auxiliary key set; QZ/ZQ empty",
            "ordinaryInitialDisplacements": 2,
            "baseFinalDisplacements": 5,
            "qzEmpty": True,
            "zqEmpty": True,
        })
        # Bare-code coverage and uniqueness are different for colliding layouts.
        entry["notes"][0] = "21x21；Common399 覆盖 399/399；M42、D2、V5；QZ 与 ZQ 均为空桶；重码按实际桶补全计费。"
        if candidate_source:
            entry["sourceSearchRound"] = "untoned-2121-other-centers-production-candidate"
            entry["r11Provenance"].update(candidate_source["source"])
            entry["r11Provenance"]["parent"] = candidate.get("parent")
            entry["r11Provenance"]["mutation"] = candidate.get("mutation")
        if candidate.get("archivedCktV4") is None:
            entry["productionCandidateMetrics"].pop("archivedCktV4", None)
        entries.append(entry)

    exact = {}
    missing_entries = []
    for entry in entries:
        path = REPLAY / "exact" / f"{entry['id']}.json"
        if path.exists() and not args.fresh:
            scored = json.loads(path.read_text(encoding="utf-8"))
            if scored.get("entry", {}).get("codeList") != entry["codeList"]:
                raise ValueError(f"stale exact replay cache: {entry['id']}")
            exact[entry["id"]] = scored
        else:
            missing_entries.append(entry)
    if missing_entries:
        exact.update(fresh_exact_replay(missing_entries, REPLAY))
    before_snapshot = helper.preservation_snapshot(data, existing_ids)
    original_cwd = Path.cwd()
    try:
        data = old.integrate_colliding(helper, data, entries, exact, REPLAY)
        helper.integrate_macroxue(data, entries, REPLAY)
    finally:
        os.chdir(original_cwd)
    if before_snapshot != helper.preservation_snapshot(data, existing_ids):
        raise ValueError("existing catalogue metrics changed")

    scope = [
        "Snow Shenyun 21x21 M42/D2 QZ+ZQ empty reviewed basin",
        f"{len(entries)} representatives from {SOURCE_BRANCH}@{SOURCE_COMMIT}",
    ]
    if scope not in data["r11Research"]["scopeRows"]:
        data["r11Research"]["scopeRows"].append(scope)
    # This catalogue-wide collision contract applies only to 21x26/21x28.
    # These 21x21 candidates cannot change its corpus or existing measurements.
    if helper.select_collision_entries(entries):
        helper.attach_four_code_collisions(data, source)
    data["fourCodeCollisionBenchmark"]["catalogueCount"] = len(data["entries"])

    v5_results = {}
    point_results = {}
    ids_arg = ",".join(entry["id"] for entry in entries)
    with tempfile.TemporaryDirectory(prefix="a7-qz-empty-six-") as location:
        temp = Path(location)
        staged = temp / "staged.html"
        staged.write_text(html[:body] + fixed.pack(data) + html[end:], encoding="utf-8")

        completion = {}
        b_scorer = RESEARCH / "score_shenyun_completion_ckt.js"
        for mapping in ("native", "fixed", "v2"):
            output = temp / f"completion-{mapping}.json"
            command = [
                "node", str(b_scorer), "--html", str(staged), "--output", str(output),
                "--ids", ids_arg, "--mapping", "fixed" if mapping == "v2" else mapping,
            ]
            if mapping == "v2":
                command.extend(["--model", "v2"])
            run(*command, cwd=SNOW)
            completion[mapping] = json.loads(output.read_text(encoding="utf-8"))["schemes"]

        for entry in entries:
            ident = entry["id"]
            for mapping, block_name in (("native", "completionB"), ("fixed", "completionBFixed")):
                block = data[block_name]
                item = completion[mapping][ident]
                block["schemes"][ident] = item
                base = block["schemes"]["S005"]["modes"]
                block["ensembleScores"][ident] = {
                    "equal": {str(t): fixed.ensemble(item["modes"], base, t, 1) for t in (0, 150, 300, 600)},
                    "word2": {str(t): fixed.ensemble(item["modes"], base, t, 2) for t in (0, 150, 300, 600)},
                }
            data["completionBV2"]["schemes"][ident] = completion["v2"][ident]

        extension = {
            "ids": [entry["id"] for entry in entries],
            "source": f"M42/D2 QZ+ZQ empty reviewed basin @ {SOURCE_COMMIT}",
            "contract": "21x21; toneKeysByTone=IVUAO; full frozen completion replay",
        }
        for block_name in ("completionB", "completionBFixed"):
            extensions = data[block_name]["source"].setdefault("extensions", [])
            if extension not in extensions:
                extensions.append(extension)

        one = copy.copy(data)
        one["entries"] = entries
        one_html = temp / "one.html"
        one_html.write_text(html[:body] + fixed.pack(one) + html[end:], encoding="utf-8")
        v3_output = temp / "completion-v3.json"
        run(
            "node", str(ROOT / "tools" / "score_completion_ckt_v3.js"),
            "--html", str(one_html), "--output", str(v3_output),
            "--limit", str(len(entries)), cwd=ROOT,
        )
        v3_schemes = json.loads(v3_output.read_text(encoding="utf-8"))["schemes"]
        for entry in entries:
            data["completionBV3"]["schemes"][entry["id"]] = v3_schemes[entry["id"]]

        staged.write_text(html[:body] + fixed.pack(data) + html[end:], encoding="utf-8")
        v4_output = temp / "completion-v4.json"
        run(
            "node", str(ROOT / "tools" / "score_completion_ckt_v4.js"),
            "--html", str(staged), "--output", str(v4_output), "--ids", ids_arg,
            "--compact", "--no-cross-audit", "--quiet", cwd=ROOT,
        )
        v4_schemes = json.loads(v4_output.read_text(encoding="utf-8"))["schemes"]
        for entry in entries:
            data["completionBV4"]["schemes"][entry["id"]] = v4_schemes[entry["id"]]

        staged.write_text(html[:body] + fixed.pack(data) + html[end:], encoding="utf-8")
        terminal_output = temp / "terminal-buckets.json"
        run(
            "node", str(ROOT / "tools" / "score_terminal_buckets.js"),
            "--html", str(staged), "--snow", str(SNOW), "--ids", ids_arg,
            "--output", str(terminal_output), cwd=ROOT,
        )
        terminal = json.loads(terminal_output.read_text(encoding="utf-8"))
        for entry in entries:
            entry["terminalBucketAudit"] = terminal[entry["id"]]

        for entry in entries:
            ident = entry["id"]
            V5_CACHE.mkdir(parents=True, exist_ok=True)
            output = V5_CACHE / f"{ident}.json"
            if output.exists() and not args.fresh:
                cached = json.loads(output.read_text(encoding="utf-8"))
                if (
                    cached.get("id") == ident
                    and cached.get("version") == "ckt-v5-v5.1-fixed-21x21-production-policies-2"
                ):
                    v5_results[ident] = cached
            if ident not in v5_results:
                v5_results[ident] = score_v5_v51_21x21(
                    ROOT / "tools" / "score_ckt_v5_v51_scheme.js",
                    staged, output, ident, temp, keytao_word3=keytao_word3, sanpin_word4=sanpin_word4,
                )
            if candidate_source and candidate_source.get("defaultPointSanpinWord4"):
                point_results[ident] = score_v5_v51_21x21(
                    ROOT / "tools" / "score_ckt_v5_v51_scheme.js", staged,
                    temp / f"{ident}-point-optimal.json", ident, temp,
                    keytao_word3=keytao_word3, sanpin_word4=candidate_source["defaultPointSanpinWord4"],
                )

    for entry in entries:
        ident = entry["id"]
        native_modes = data["completionB"]["schemes"][ident]["modes"]
        entry["bPathMetricsNative"] = {
            key: native_modes[mode][kind][stage]
            for key, mode, kind, stage in NATIVE_B_PATHS
        }
        metrics = readme_metrics(data, entry, v5_results[ident], production)
        if ident in point_results:
            metrics["cktV51DefaultPointOptimal"] = point_results[ident]["cktV51"]["score"]
        validate_expected(metrics, candidate_by_id[ident].get("expected", {}))
        entry["readmeBenchmarkMetrics"] = metrics
        entry["productionCandidateMetrics"].update({
            "replayedCktV3": metrics["cktV3"],
            "replayedCktV4": metrics["cktV4"],
            "replayedCktV5": metrics["cktV5"],
            "replayedCktV51": metrics["cktV51"],
            "cktV4Aggregate": production.aggregate_v4(
                data["completionBV4"]["schemes"][ident]["modes"]
            ),
            "cktV5Aggregate": v5_results[ident]["cktV5"]["aggregate"],
            "cktV51Aggregate": v5_results[ident]["cktV51"]["aggregate"],
            "cktV5Policies": v5_results[ident]["cktV5"]["policies"],
            "cktV51Policies": v5_results[ident]["cktV51"]["policies"],
        })
        if ident in point_results:
            point = point_results[ident]["cktV51"]
            entry["productionCandidateMetrics"].update({
                "cktV51DefaultPointOptimal": point["score"],
                "cktV51DefaultPointPolicies": point["policies"],
                "cktV51DefaultPointAggregate": point["aggregate"],
                "cktV51AuxOrderSelection": candidate_source["auxOrderSelection"],
            })
        if candidate_source and candidate_source.get('productionDisplay') == 'robust-v51':
            apply_robust_production_display(entry, candidate_source['auxOrderSelection'])
        if ident == E8F37A_ID:
            entry["productionCandidateMetrics"]["cktV51AuxOrderRobustness"] = copy.deepcopy(
                E8F37A_ROBUSTNESS
            )
    data["bPathBenchmark"]["schemeCount"] = sum(
        len(candidate.get("bPathMetricsNative", {})) == len(NATIVE_B_PATHS)
        for candidate in data["entries"]
    )

    all_ids = existing_ids | candidate_ids
    after_missing = production.missing_by_map(data, all_ids)
    for name, missing in after_missing.items():
        if missing != before_missing[name]:
            raise ValueError(f"incomplete or changed benchmark map {name}: {sorted(missing)}")

    audit = {
        "version": ("untoned-2121-production-candidate-full-benchmark-v2" if candidate_source.get('productionDisplay') == 'robust-v51'
                    else "untoned-2121-production-candidate-full-benchmark-v1") if candidate_source else "a7-qz-zq-empty-m42d2-six-full-benchmark-v1",
        "catalogueCount": len(data["entries"]),
        "source": {"branch": SOURCE_BRANCH, "commit": SOURCE_COMMIT},
        "auxiliarySemantics": {
            "toneKeysByTone": TONE_KEYS_BY_TONE,
            "shapeKeysByMeaning": SHAPE_KEYS_BY_MEANING,
            "toneDigitsByShapeMeaning": TONE_DIGITS_BY_SHAPE_MEANING,
        },
        "schemes": {},
        "replacedIds": replaced_ids,
    }
    if candidate_source:
        audit["candidateSource"] = candidate_source
    for entry in entries:
        ident = entry["id"]
        audit["schemes"][ident] = {
            "label": candidate_by_id[ident]["label"],
            "stateKey": candidate_by_id[ident]["stateKey"],
            "mappingAudit": entry["mappingAudit"],
            "memoryAuditR2": entry["memoryAuditR2"],
            "logicUniformity": entry["logicUniformity"],
            "logicAudit": entry["logicAudit"],
            "productionCandidateMetrics": entry["productionCandidateMetrics"],
            "readmeBenchmarkMetrics": entry["readmeBenchmarkMetrics"],
            "terminalBucketAudit": entry["terminalBucketAudit"],
            "fourCodeCollision": entry.get("fourCodeCollision"),
            "cktTracks": data["ckt"]["tracks"][ident],
            "fairCKT": data["fairCKT"]["values"][ident],
            "ensemble": {
                name: data[name]["values"][ident]
                for name in ("ensemble", "ensembleV2", "ensembleV3", "ensembleV4", "ensembleV5", "ensembleV6")
            },
            "load": data["r11LoadSummaries"][ident],
            "pair": data["r11PairMetrics"]["values"][ident],
            "macroxue": data["macroxue"]["values"][ident],
            "completionB": data["completionB"]["schemes"][ident],
            "completionBFixed": data["completionBFixed"]["schemes"][ident],
            "completionBV2": data["completionBV2"]["schemes"][ident],
            "completionBV3": data["completionBV3"]["schemes"][ident],
            "completionBV4": data["completionBV4"]["schemes"][ident],
            "cktV5V51": v5_results[ident],
            "cktV51DefaultPointOptimalReplay": point_results.get(ident),
        }
    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    AUDIT.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    if HTML.read_text(encoding="utf-8") != html:
        raise ValueError("HTML changed during scoring; rerun against the latest page")
    fixed.write_payload(HTML, patch_production_ui(html) if candidate_source else html, body, end, data)
    print(json.dumps({
        "html": str(HTML),
        "audit": str(AUDIT),
        "catalogue": len(data["entries"]),
        "added": [entry["id"] for entry in entries if entry["id"] not in replaced_ids],
        "updated": replaced_ids,
        "htmlSha256": hashlib.sha256(HTML.read_bytes()).hexdigest(),
        "metrics": {entry["id"]: entry["readmeBenchmarkMetrics"] for entry in entries},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
